'use client';

import { X, ExternalLink, MapPin, Calendar, Users, Clock, Scale } from 'lucide-react';
import Link from 'next/link';

interface FeatureProperties {
  name: string;
  type: string;
  category: string;
  description?: string;
  diameter?: number;
  depth?: number;
  age?: string;
  formed?: string;
  englishName?: string;
  // Apollo-specific
  mission?: string;
  location?: string;
  date?: string;
  crew?: string[];
  cmpilot?: string;
  surfaceDuration?: string;
  evaDuration?: string;
  samples?: number;
  roverDistance?: number;
  artifacts?: string[];
  firstWords?: string;
  lastWords?: string;
  [key: string]: unknown;
}

interface InfoPanelProps {
  feature: {
    id: string;
    properties: FeatureProperties;
  } | null;
  onClose: () => void;
}

export default function InfoPanel({ feature, onClose }: InfoPanelProps) {
  if (!feature) return null;

  const { properties } = feature;
  const isApollo = properties.category === 'apollo';
  const isMare = properties.type === 'mare';
  const isCrater = properties.type === 'crater';

  return (
    <div className="absolute bottom-0 left-0 right-0 md:bottom-auto md:top-4 md:left-4 md:right-auto md:w-96 z-[1000] bg-white rounded-t-xl md:rounded-xl shadow-xl max-h-[70vh] overflow-hidden flex flex-col">
      {/* Header */}
      <div className="flex items-start justify-between p-4 border-b border-neutral-100">
        <div>
          <h2 className="text-xl font-light text-black">
            {properties.name}
          </h2>
          {properties.englishName && (
            <p className="text-sm text-black/50">{properties.englishName}</p>
          )}
          {properties.location && !properties.englishName && (
            <p className="text-sm text-black/50 flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              {properties.location}
            </p>
          )}
        </div>
        <button
          onClick={onClose}
          className="p-2 hover:bg-neutral-100 rounded-lg transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Apollo mission details */}
        {isApollo && (
          <>
            {properties.date && (
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="w-4 h-4 text-black/40" />
                <span>
                  {new Date(properties.date).toLocaleDateString('en-GB', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}
                </span>
              </div>
            )}

            {properties.crew && (
              <div className="flex items-start gap-2 text-sm">
                <Users className="w-4 h-4 text-black/40 mt-0.5" />
                <div>
                  <p className="font-medium">Surface crew</p>
                  <p className="text-black/70">{properties.crew.join(' & ')}</p>
                  {properties.cmpilot && (
                    <p className="text-black/50 text-xs mt-1">
                      Command module: {properties.cmpilot}
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Stats grid */}
            <div className="grid grid-cols-2 gap-3">
              {properties.surfaceDuration && (
                <div className="bg-neutral-50 rounded-lg p-3">
                  <p className="text-xs text-black/50 uppercase tracking-wider mb-1">
                    Surface time
                  </p>
                  <p className="text-sm font-mono">{properties.surfaceDuration}</p>
                </div>
              )}
              {properties.evaDuration && (
                <div className="bg-neutral-50 rounded-lg p-3">
                  <p className="text-xs text-black/50 uppercase tracking-wider mb-1">
                    EVA time
                  </p>
                  <p className="text-sm font-mono">{properties.evaDuration}</p>
                </div>
              )}
              {properties.samples && (
                <div className="bg-neutral-50 rounded-lg p-3">
                  <p className="text-xs text-black/50 uppercase tracking-wider mb-1">
                    Samples
                  </p>
                  <p className="text-sm font-mono">{properties.samples} kg</p>
                </div>
              )}
              {properties.roverDistance && (
                <div className="bg-neutral-50 rounded-lg p-3">
                  <p className="text-xs text-black/50 uppercase tracking-wider mb-1">
                    Rover distance
                  </p>
                  <p className="text-sm font-mono">{properties.roverDistance} km</p>
                </div>
              )}
            </div>
          </>
        )}

        {/* Crater details */}
        {isCrater && (
          <div className="grid grid-cols-2 gap-3">
            {properties.diameter && (
              <div className="bg-neutral-50 rounded-lg p-3">
                <p className="text-xs text-black/50 uppercase tracking-wider mb-1">
                  Diameter
                </p>
                <p className="text-sm font-mono">{properties.diameter} km</p>
              </div>
            )}
            {properties.depth && (
              <div className="bg-neutral-50 rounded-lg p-3">
                <p className="text-xs text-black/50 uppercase tracking-wider mb-1">
                  Depth
                </p>
                <p className="text-sm font-mono">{(properties.depth / 1000).toFixed(1)} km</p>
              </div>
            )}
            {properties.age && (
              <div className="bg-neutral-50 rounded-lg p-3 col-span-2">
                <p className="text-xs text-black/50 uppercase tracking-wider mb-1">
                  Age
                </p>
                <p className="text-sm">{properties.age}</p>
              </div>
            )}
          </div>
        )}

        {/* Mare details */}
        {isMare && (
          <div className="grid grid-cols-2 gap-3">
            {properties.diameter && (
              <div className="bg-neutral-50 rounded-lg p-3">
                <p className="text-xs text-black/50 uppercase tracking-wider mb-1">
                  Diameter
                </p>
                <p className="text-sm font-mono">{properties.diameter} km</p>
              </div>
            )}
            {properties.formed && (
              <div className="bg-neutral-50 rounded-lg p-3 col-span-2">
                <p className="text-xs text-black/50 uppercase tracking-wider mb-1">
                  Formation
                </p>
                <p className="text-sm">{properties.formed}</p>
              </div>
            )}
          </div>
        )}

        {/* Description */}
        {properties.description && (
          <p className="text-sm text-black/70 leading-relaxed">
            {properties.description}
          </p>
        )}

        {/* First/last words */}
        {properties.firstWords && (
          <blockquote className="border-l-2 border-black/20 pl-3 italic text-sm text-black/60">
            "{properties.firstWords}"
          </blockquote>
        )}
        {properties.lastWords && (
          <blockquote className="border-l-2 border-black/20 pl-3 italic text-sm text-black/60">
            "{properties.lastWords}"
          </blockquote>
        )}

        {/* Artifacts */}
        {properties.artifacts && properties.artifacts.length > 0 && (
          <div>
            <p className="text-xs text-black/50 uppercase tracking-wider mb-2">
              Left on surface
            </p>
            <div className="flex flex-wrap gap-2">
              {properties.artifacts.map((artifact, i) => (
                <span
                  key={i}
                  className="px-2 py-1 bg-neutral-100 rounded text-xs"
                >
                  {artifact}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-neutral-100 bg-neutral-50">
        <Link
          href={`/data/moon/${feature.id}`}
          className="flex items-center justify-center gap-2 w-full py-2 px-4 bg-black text-white rounded-lg text-sm font-medium hover:bg-black/80 transition-colors"
        >
          View full details
          <ExternalLink className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
